create database docker;

use docker;

create table pass(
name varchar(20),
pass varchar(20));
insert into pass values('devops','test');

